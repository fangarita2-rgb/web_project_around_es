# Around The U.S. — Proyecto 8

**Proyecto: Around The U.S. (Refactorización POO con TypeScript)**

### Descripción del Proyecto

Around The U.S. es una página web interactiva donde los usuarios pueden explorar y compartir fotografías de lugares interesantes a lo largo de los Estados Unidos. En esta etapa del proyecto, se realizó una refactorización completa del código utilizando Programación Orientada a Objetos (POO) y TypeScript, organizando toda la lógica en clases independientes y reutilizables.

### Funcionalidad

- **Editar perfil**: El usuario puede modificar su nombre y descripción a través de un modal con formulario validado.
- **Agregar tarjetas**: El usuario puede añadir nuevas tarjetas con título e imagen personalizada desde un modal con validación en tiempo real.
- **Eliminar tarjetas**: Cada tarjeta tiene un botón para eliminarla del DOM.
- **Me gusta**: El usuario puede marcar y desmarcar favoritos en cada tarjeta.
- **Vista ampliada**: Al hacer clic en la imagen de una tarjeta, se abre un modal con la imagen en tamaño grande y su título.
- **Validación de formularios**: Los campos se validan en tiempo real usando `ValidityState`. El botón de envío se deshabilita si algún campo no es válido.
- **Cierre de modales**: Los modales se cierran con el botón X, haciendo clic fuera del contenido o pulsando la tecla Esc.

### Arquitectura POO — Clases

- **`FormValidator`**: Valida los campos de un formulario en tiempo real. Métodos públicos: `enableValidation()` y `resetValidation()`.
- **`Card`**: Crea elementos de tarjeta individuales a partir de datos. Aplica acoplamiento débil pasando el callback `handleCardClick`.
- **`Section`**: Renderiza listas de elementos en un contenedor del DOM.
- **`Popup`**: Clase base para ventanas modales. Maneja apertura, cierre con Esc y clic fuera.
- **`PopupWithImage`**: Extiende `Popup`. Muestra imágenes ampliadas con título.
- **`PopupWithForm`**: Extiende `Popup`. Maneja envío de formularios y reseteo al cerrar.
- **`UserInfo`**: Gestiona la lectura y escritura de los datos del perfil de usuario en el DOM.

### Tecnologías y Técnicas Utilizadas

- **HTML5 y CSS3**: Estructura y diseño con metodología BEM.
- **TypeScript (ES6+)**: Tipado estático, interfaces, clases, herencia, genéricos y módulos ES6.
- **Programación Orientada a Objetos**: Encapsulamiento, herencia, acoplamiento débil y responsabilidad única por clase.
- **Validación con `ValidityState`**: Validación nativa del navegador con mensajes personalizados.
- **Git y GitHub Pages**: Control de versiones y despliegue.
